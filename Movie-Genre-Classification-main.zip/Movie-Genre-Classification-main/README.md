 Movie Genre Classification using Machine Learning

#Project Overview

This project focuses on predicting the genre of a movie based on its plot description. Using Natural Language Processing (NLP) techniques and Machine Learning algorithms, the model learns patterns from movie summaries and classifies them into appropriate genres.
The project was developed using the IMDb Genre Classification dataset and demonstrates the complete machine learning workflow, including data preprocessing, feature extraction, model training, evaluation, and prediction.

# Dataset

The dataset contains movie titles, genres, and plot descriptions collected from IMDb.
Files used:
- train_data.txt
- test_data.txt
- test_data_solution.txt

# Technologies Used

- Python
- Pandas
- NumPy
- Scikit-Learn
- TF-IDF Vectorization
- Matplotlib
- Machine Learning

# Machine Learning Models

The following models were trained and evaluated:
1. Multinomial Naive Bayes
2. Logistic Regression
3. Linear Support Vector Machine (SVM)

# Project Workflow

1. Load and explore the dataset
2. Clean and preprocess movie descriptions
3. Convert text into numerical features using TF-IDF
4. Train machine learning models
5. Evaluate model performance using accuracy and classification metrics
6. Predict genres for unseen movie descriptions
7. Save the trained model for future use

# Results

After comparing multiple algorithms, the Linear SVM model produced the best performance and was selected as the final model.

# Evaluation Metrics
- Accuracy Score
- Precision
- Recall
- F1-Score

# Example Prediction

Input:

> "A group of astronauts travel through space to save humanity."

**Predicted Genre:**

> Sci-Fi

# Saved Files

-genre_model.pkl – Trained SVM model
-tfidf.pkl – TF-IDF vectorizer

These files allow predictions without retraining the model.

# Future Improvements

- Deploy the model as a web application using Flask or Streamlit
- Improve accuracy using advanced NLP techniques
- Experiment with Deep Learning models such as LSTM and BERT
- Add a user-friendly interface for genre prediction

# Author
Shreyas Biware
B.Tech Information Technology Student  
SVKM's NMIMS MPSTME, Shirpur

# Internship Project

This project was completed as part of a Machine Learning Internship to gain practical experience in Natural Language Processing and Text Classification.